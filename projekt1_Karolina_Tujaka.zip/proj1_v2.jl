using LinearAlgebra
include("FEM.jl")
using PyPlot
using IterativeSolvers

A, b = femproblem(10, 10)



#starting point
x0 = zeros(size(A,1))
x = zeros(size(A,1))

#max ammount of Iterations
max_m = 500
m = 0

xg = gmres(A, b)
print(xg, '\n')

r = b - A*x0

beta = norm(r,2)
beta2 = norm(r,2)

q = zeros((size(A,1), max_m))
q[:,1] = r./beta

h = zeros((max_m+1, max_m))

e = zeros(max_m+1)
e[1] = 1

err = Float64[]

while (m != max_m)    
    global m, q, x, r, beta2, err
    m = m+1

    y = A*q[:,m]    

    for j in 1:m
        h[j, m] = (q[:,j]' * y)
        y = y - h[j, m] * q[:,j] 
    end


    h[m + 1, m] = norm(y,2)

    if (h[m + 1, m] != 0) && (m != max_m)
        q[:,m + 1] = y / h[m + 1, m]
    end


    c = h[1:m,1:m]\(beta*e[1:m])

    x = q[:,1:m]*c + x0
    r = b - A*x
    beta2 = norm(r,2)

    push!(err, beta2)

    #accuracy
    beta2 < 1e-32 && break
  
end

xe = A\b
print(x, '\n')
print(xe, '\n')

plt.plot(1:size(err,1), err)
plt.title("% error GMRES method")
plt.xlabel("Iterations")
plt.ylabel("Error")
plt.show()

plt.scatter(1:1:size(A,1), xe, label = "Exact value")
plt.scatter(1:1:size(A,1), xg, label = "GMRES method from Julia")
plt.scatter(1:1:size(A,1), x, label = "implemented GMRES method")
plt.title("Comparison GMRES methods to original value")
plt.xlabel("Vector elements")
plt.ylabel("Value")
plt.legend()
plt.show()
